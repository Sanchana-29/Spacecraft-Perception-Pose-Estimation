import Layout from "../components/Layout/Layout";
import "./Sensors.css";

import SensorTabs from "../components/Sensors/SensorTabs/SensorTabs";
import SensorViewer from "../components/Sensors/SensorViewer/SensorViewer";
import SensorConfiguration from "../components/Sensors/SensorConfiguration/SensorConfiguration";
import SensorInformation from "../components/Sensors/SensorInformation/SensorInformation";

function Sensors() {
  return (
 <Layout
    showInspector={false}
    showFooter={false}
>
  <div className="sensors-page">

    <SensorTabs />

    <SensorViewer />

  </div>
</Layout>
  );
}

export default Sensors;