import Layout from "../components/Layout/Layout";
import Scene from "../components/Scene/Scene";
import FloatingWindow from "../components/FloatingWindow/FloatingWindow";
import { FaCamera } from "react-icons/fa";

import { useWindow } from "../context/WindowContext";

function Dashboard() {
  const { showCamera } = useWindow();

  return (
    <Layout>
      <Scene />

      {showCamera && (
        <FloatingWindow
          title="RGB Camera"
          icon={<FaCamera />}
        >
          Camera Feed
        </FloatingWindow>
      )}
    </Layout>
  );
}

export default Dashboard;