import "./BottomControls.css";
import {
  FaPlay,
  FaPause,
  FaRedoAlt,
} from "react-icons/fa";

function BottomControls() {
  return (
    <div className="bottom-controls">

      <div className="control-buttons">
        <button>
          <FaPlay />
          Play
        </button>

        <button>
          <FaPause />
          Pause
        </button>

        <button>
          <FaRedoAlt />
          Reset
        </button>
      </div>

      <div className="simulation-speed">
        <label>Simulation Speed</label>

        <input
          type="range"
          min="0.5"
          max="5"
          step="0.5"
          defaultValue="1"
        />

        <span>1x</span>
      </div>

      <div className="mission-time">
        <label>Mission Time</label>
        <span>00:00:00</span>
      </div>

    </div>
  );
}

export default BottomControls;