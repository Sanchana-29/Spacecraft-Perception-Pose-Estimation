import "./ObjectInspector.css";

function ObjectInspector() {
  return (
    <div className="object-inspector">

      <h2>Object Inspector</h2>

      <section>
        <h3>Object Information</h3>

        <div className="row">
          <span>Object ID</span>
          <span>--</span>
        </div>

        <div className="row">
          <span>Object Name</span>
          <span>--</span>
        </div>

        <div className="row">
          <span>Object Type</span>
          <span>--</span>
        </div>

        <div className="row">
          <span>Status</span>
          <span>--</span>
        </div>
      </section>

      <section>
        <h3>Relative State</h3>

        <div className="row">
          <span>Distance</span>
          <span>--</span>
        </div>

        <div className="row">
          <span>Velocity</span>
          <span>--</span>
        </div>

        <div className="row">
          <span>Position</span>
          <span>--</span>
        </div>
      </section>

      <section>
        <h3>Attitude</h3>

        <div className="row">
          <span>Roll</span>
          <span>--</span>
        </div>

        <div className="row">
          <span>Pitch</span>
          <span>--</span>
        </div>

        <div className="row">
          <span>Yaw</span>
          <span>--</span>
        </div>
      </section>

      <section>
        <h3>Tracking</h3>

        <div className="row">
          <span>Tracking Status</span>
          <span>--</span>
        </div>

        <div className="row">
          <span>Confidence</span>
          <span>--</span>
        </div>
      </section>

    </div>
  );
}

export default ObjectInspector;