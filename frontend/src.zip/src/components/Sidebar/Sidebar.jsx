import { NavLink } from "react-router-dom";
import {
  FaSatellite,
  FaTachometerAlt,
  FaGlobe,
  FaCamera,
  FaEye,
  FaCube,
  FaChartLine,
  FaFileAlt,
  FaCog,
} from "react-icons/fa";

import { useWindow } from "../../context/WindowContext";

import "./Sidebar.css";

function Sidebar() {
  const { setShowCamera } = useWindow();

  return (
    <div className="sidebar-container">
      <div className="logo">
        <FaSatellite size={28} />
        <h2>SpaceTug</h2>
      </div>

      <nav>
        <NavLink to="/dashboard">
          <FaTachometerAlt />
          Dashboard
        </NavLink>

       
<NavLink to="/sensors">
  <FaCamera />
  Sensors
</NavLink>

       <NavLink to="/detection">
          <FaEye />
         Detection
        </NavLink>
<NavLink to="/pose-estimation">
    <FaCube />
    Pose Estimation
</NavLink>
        <NavLink to="/telemetry">
    <FaChartLine />
    Telemetry
</NavLink>

        <NavLink to="/mission-summary">
          <FaFileAlt />
          Mission Summary
        </NavLink>

        <NavLink to="/settings">
          <FaCog />
          Settings
        </NavLink>
      </nav>
    </div>
  );
}

export default Sidebar;