import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import TargetSpacecraft from "../Spacecraft/TargetSpacecraft";
import Earth from "./Earth";
import StarsField from "./StarsField";
import SunLight from "./SunLight";

function Scene() {
  return (
    <div style={{ width: "100%", height: "100%" }}>
      <Canvas
        camera={{
          position: [0, 0, 3.5],
          fov: 45,
        }}
      >
        <SunLight />

        <StarsField />

    <Earth />

{/*<TargetSpacecraft />*/}

<OrbitControls
  enablePan={false}
  minDistance={2}
  maxDistance={8}
/>
      </Canvas>
    </div>
  );
}

export default Scene;