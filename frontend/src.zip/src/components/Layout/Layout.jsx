import TopBar from "../TopBar/TopBar";
import Sidebar from "../Sidebar/Sidebar";
import ObjectInspector from "../ObjectInspector/ObjectInspector";
import BottomControls from "../BottomControls/BottomControls";

import "./Layout.css";

function Layout({
  children,
  showInspector = true,
  showFooter = true,
}) {
  return (
   <div
  className={`layout
    ${showInspector ? "with-inspector" : "without-inspector"}
    ${showFooter ? "with-footer" : "without-footer"}
  `}
>
      <header className="topbar">
        <TopBar />
      </header>

      <aside className="sidebar">
        <Sidebar />
      </aside>

      <main className="content">
        {children}
      </main>

      {showInspector && (
        <aside className="inspector">
          <ObjectInspector />
        </aside>
      )}

      {showFooter && (
  <footer className="footer">
    <BottomControls />
  </footer>
)}
    </div>
  );
}

export default Layout;