import { useFrame } from "@react-three/fiber";
import { useRef } from "react";

function TargetSpacecraft() {
  const spacecraftRef = useRef();

  useFrame(() => {
    spacecraftRef.current.rotation.y += 0.003;
  });

  return (
    <group ref={spacecraftRef} position={[3, 0, 0]}>

      {/* Main Body */}
      <mesh>
        <boxGeometry args={[0.4, 0.4, 0.6]} />
        <meshStandardMaterial color="silver" />
      </mesh>

      {/* Left Solar Panel */}
      <mesh position={[-0.7, 0, 0]}>
        <boxGeometry args={[1, 0.03, 0.5]} />
        <meshStandardMaterial color="#1E90FF" />
      </mesh>

      {/* Right Solar Panel */}
      <mesh position={[0.7, 0, 0]}>
        <boxGeometry args={[1, 0.03, 0.5]} />
        <meshStandardMaterial color="#1E90FF" />
      </mesh>

    </group>
  );
}

export default TargetSpacecraft;