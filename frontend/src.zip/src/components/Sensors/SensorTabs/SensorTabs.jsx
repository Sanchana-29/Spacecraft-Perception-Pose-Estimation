import "./SensorTabs.css";

import {
  FaCamera,
  FaCube,
  FaFire,
  FaSatelliteDish,
} from "react-icons/fa";

function SensorTabs() {
  const sensors = [
      {
      name: "RGB-D Camera",
      icon: <FaCube />,
    },
   
    {
      name: "Stereo Camera",
      icon: <FaCamera />,
    },
  
    {
      name: "Thermal Camera",
      icon: <FaFire />,
    },
    {
      name: "LiDAR",
      icon: <FaSatelliteDish />,
    },
  ];

  return (
    <div className="sensor-tabs">

      {sensors.map((sensor, index) => (

        <div className="sensor-card" key={index}>

          <div className="sensor-icon">
            {sensor.icon}
          </div>

          <h3>{sensor.name}</h3>

          <span className="sensor-status">
            🟢 Active
          </span>

        </div>

      ))}

    </div>
  );
}

export default SensorTabs;