import "./SensorViewer.css";
import { useSensor } from "../../../context/SensorContext";

function SensorViewer() {

    const { selectedSensor } = useSensor();

    return (

        <div className="sensor-viewer">

            <div className="viewer-header">

                <h2>{selectedSensor}</h2>

                <span className="live-status">
                    🟢 LIVE
                </span>

            </div>

            <div className="viewer-content">

                {selectedSensor} Preview

            </div>

        </div>

    );
}

export default SensorViewer;