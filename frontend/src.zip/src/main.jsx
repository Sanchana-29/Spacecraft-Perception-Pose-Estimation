import React from "react";
import ReactDOM from "react-dom/client";

import App from "./App";

import "./index.css";

import { WindowProvider } from "./context/WindowContext";
import { SensorProvider } from "./context/SensorContext";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <WindowProvider>
      <SensorProvider>
        <App />
      </SensorProvider>
    </WindowProvider>
  </React.StrictMode>
);